package com.example.shiv.prime_number;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends Activity implements OnClickListener
{
    Random r = new Random();
    int i1 = r.nextInt(1000 - 1) + 1;
    private EditText rnd_num ;
    private Button correct_btn, incorrect_btn, next_btn;
    protected void onCreate(Bundle savedInstanceState)
    {
        String message =
                    "Random Generator value is " + i1;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("INFO", "State of activity MainActivity created");
        rnd_num = (EditText) findViewById(R.id.rnd_num);
        correct_btn = (Button) findViewById(R.id.btn_correct);
        incorrect_btn= (Button) findViewById(R.id.btn_incorrect);
        next_btn = (Button) findViewById(R.id.btn_next);
        correct_btn.setOnClickListener(this);
        incorrect_btn.setOnClickListener(this);
        next_btn.setOnClickListener(this);
        rnd_num.setText(message);
    }

    public  void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btn_correct:
                    int i,m=0,flag=0;
                    int n=i1;//it is the number to be checked
                    m=n/2;
                    for(i=2;i<=m;i++)
                    {
                        if(n%i==0)
                        {
                            Toast.makeText(MainActivity.this, "Number is not prime: You are Wrong", Toast.LENGTH_LONG).show();
                            flag=1;
                            break;
                        }
                    }
                    if(flag==0)
                        Toast.makeText(MainActivity.this, "Number is prime: You are Right", Toast.LENGTH_LONG).show();

            break;

            case R.id.btn_incorrect:
                int ii,m1=0,flag1=0;
                int n1=i1;//it is the number to be checked
                m=n1/2;
                for(ii=2;ii<=m;ii++)
                {
                    if(n1%ii==0)
                    {
                        Toast.makeText(MainActivity.this, "Number is not prime:You are Correct", Toast.LENGTH_LONG).show();
                        flag1=1;
                        break;
                    }
                }
                if(flag1==0)
                    Toast.makeText(MainActivity.this, "Number is prime: You are wrong", Toast.LENGTH_LONG).show();

                break;

            case R.id.btn_next:
                setContentView(R.layout.ctivitymain2);

                break;
            default:
                break;
        }
    }

    };
